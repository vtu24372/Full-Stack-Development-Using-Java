package com.vir.b30.spring.java_based_bean_config;

public interface Publish {

	public void show();
	
}
